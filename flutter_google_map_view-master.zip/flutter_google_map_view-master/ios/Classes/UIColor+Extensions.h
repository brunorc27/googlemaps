//
// Created by Matthew Smith on 11/7/17.
//

#import <Foundation/Foundation.h>

@interface UIColor (Extensions)
+ (UIColor *)colorFromDictionary:(NSDictionary *)dictionary;
@end