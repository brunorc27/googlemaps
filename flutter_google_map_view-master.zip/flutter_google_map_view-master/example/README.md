# map_view_example

Demonstrates how to use the map_view plugin.

## Getting Started

For help getting started with Flutter, view our online
[documentation](http://flutter.io/).
