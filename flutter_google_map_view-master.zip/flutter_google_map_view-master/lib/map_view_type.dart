
enum MapViewType { none, normal, satellite, terrain, hybrid }

enum StaticMapViewType { roadmap, satellite, terrain, hybrid }
