import 'location.dart';

class Locations {
  static Location portland = new Location(45.512794, -122.679565);
  static Location centerOfUSA = new Location(37.0902, -95.7192);
}
